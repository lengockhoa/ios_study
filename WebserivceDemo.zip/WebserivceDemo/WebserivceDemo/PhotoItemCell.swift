//
//  PhotoItemCell.swift
//  WebserivceDemo
//
//  Created by Sua Le on 5/3/17.
//  Copyright © 2017 Sua Le. All rights reserved.
//

import UIKit

class PhotoItemCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var photoView: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
